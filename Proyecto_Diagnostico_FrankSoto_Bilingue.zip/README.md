# 🧾 Diagnóstico Técnico / Technical Diagnostic – Ubuntu 24.04.3 LTS on Toshiba Satellite C875

![Ubuntu 24.04.3 LTS](https://img.shields.io/badge/Ubuntu-24.04.3%20LTS-orange?logo=ubuntu)
![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)
![Platform: Toshiba C875](https://img.shields.io/badge/Platform-Toshiba%20C875-lightgrey)

**Autor / Author:** Frank Soto  
**Fecha / Date:** October 27, 2025  

---

## 📋 Descripción del Proyecto / Project Description

**ES:**  
Prueba realizada en entorno real, con fines de análisis y optimización de rendimiento.  
Este diagnóstico fue realizado sobre una laptop **Toshiba Satellite C875** con las siguientes especificaciones:

- **CPU:** Intel Core i7 (actualizado desde i3)  
- **RAM:** 16 GB DDR3  
- **Almacenamiento:** SSD de 1 TB  
- **Sistema operativo:** Ubuntu 24.04.3 LTS  

**EN:**  
Real-world performance test aimed at system analysis and optimization.  
This diagnostic was performed on a **Toshiba Satellite C875** laptop with the following specs:

- **CPU:** Intel Core i7 (upgraded from i3)  
- **RAM:** 16 GB DDR3  
- **Storage:** 1 TB SSD  
- **Operating System:** Ubuntu 24.04.3 LTS  

---

## 🧠 Objetivo / Objective

**ES:**  
Analizar el rendimiento real del sistema tras una instalación limpia y actualizada de Ubuntu 24.04.3 LTS.  
Las pruebas incluyen CPU, memoria, GPU y monitoreo de temperatura en tiempo real.  

**EN:**  
To analyze the real performance of the system after a clean and updated installation of Ubuntu 24.04.3 LTS.  
Tests include CPU, memory, GPU, and real-time temperature monitoring.

---

## ⚙️ Herramientas Utilizadas / Tools Used

- **sysbench** → CPU and memory benchmarking  
- **glmark2** → GPU performance test  
- **inxi** → full system diagnostic  
- **lm-sensors** → temperature sensors reading  

---

## 📄 Instrucciones de Uso / Usage Instructions

**ES:**  
1. Dar permisos de ejecución al script:  
   ```bash
   chmod +x diagnostico_frank.sh
   ```
2. Ejecutar el diagnóstico con privilegios de administrador:  
   ```bash
   sudo ./diagnostico_frank.sh
   ```
3. Los resultados se guardarán en la carpeta:  
   ```bash
   ~/diagnostico_frank_resultados/
   ```

**EN:**  
1. Give execution permission to the script:  
   ```bash
   chmod +x diagnostico_frank.sh
   ```
2. Run the diagnostic with admin privileges:  
   ```bash
   sudo ./diagnostico_frank.sh
   ```
3. Results will be saved in the following directory:  
   ```bash
   ~/diagnostico_frank_resultados/
   ```

---

## 🌐 Contacto / Contact

📧 **1972sotof@gmail.com**

---

**© 2025 Frank Soto**  
Proyecto educativo y de análisis técnico. / Educational and technical analysis project.
