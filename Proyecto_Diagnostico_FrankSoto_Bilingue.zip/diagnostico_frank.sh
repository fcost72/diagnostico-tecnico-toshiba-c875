#!/bin/bash
# ============================================================
# 🧾 Script de diagnóstico técnico - Frank Soto
# Sistema probado: Ubuntu 24.04.3 LTS en Toshiba Satellite C875
# Fecha: 27 de octubre de 2025
# ============================================================

# 🧠 Descripción:
# Este script ejecuta un conjunto de pruebas básicas de rendimiento
# (CPU, memoria y GPU) y guarda los resultados en un archivo de texto.
# Está diseñado para entornos reales, no virtualizados.

# ------------------------------------------------------------
# 🧰 Requisitos previos:
# sudo apt install sysbench glmark2 inxi lm-sensors -y
# ------------------------------------------------------------

RESULT_DIR="$HOME/diagnostico_frank_resultados"
mkdir -p "$RESULT_DIR"
OUTPUT="$RESULT_DIR/diagnostico_$(date +%Y-%m-%d_%H-%M-%S).txt"

echo "============================================================" | tee -a "$OUTPUT"
echo " DIAGNÓSTICO TÉCNICO - FRANK SOTO " | tee -a "$OUTPUT"
echo " Ubuntu 24.04.3 LTS - Toshiba C875 " | tee -a "$OUTPUT"
echo " Fecha: $(date)" | tee -a "$OUTPUT"
echo "============================================================" | tee -a "$OUTPUT"

echo "📋 INFORMACIÓN DEL SISTEMA:" | tee -a "$OUTPUT"
inxi -Fxz | tee -a "$OUTPUT"

echo "🧠 PRUEBA DE CPU (sysbench)..." | tee -a "$OUTPUT"
sysbench cpu --threads=4 --time=10 run | tee -a "$OUTPUT"

echo "💾 PRUEBA DE MEMORIA (sysbench)..." | tee -a "$OUTPUT"
sysbench memory --memory-block-size=1M --memory-total-size=10G run | tee -a "$OUTPUT"

echo "🎮 PRUEBA DE GPU (glmark2)..." | tee -a "$OUTPUT"
glmark2 | tee -a "$OUTPUT"

echo "🌡️ TEMPERATURAS DEL SISTEMA:" | tee -a "$OUTPUT"
sensors | tee -a "$OUTPUT"

echo "============================================================" | tee -a "$OUTPUT"
echo "✅ Pruebas completadas con éxito" | tee -a "$OUTPUT"
echo "Archivo de resultados guardado en:" | tee -a "$OUTPUT"
echo "$OUTPUT" | tee -a "$OUTPUT"
echo "============================================================" | tee -a "$OUTPUT"
